# Sigma Primary KPI Tiles: SAC custom widget

One tile per primary KPI, like the "Seven primary KPIs" row on the Sigma Operational Performance page. Each tile shows:

- the **KPI score**, with its status band in colour and in words
- the **contribution** to overall: (score - 80) x weight / 100
- the **impact**: High, Medium or Low
- a **trend line** for the last 90 days, with a dashed target line and a hover tooltip

Clicking a tile selects that KPI (the `onSelect` event).

`preview.png` shows the widget with the prototype's enterprise figures, wide and narrow.

## Files

| File | Where it goes |
|---|---|
| `SigmaKpiPrimary.js` | GitHub Pages: `https://dpaonam.github.io/SigmaKpiPrimary.js` |
| `SigmaKpiPrimary.json` | Upload to SAC (Files > Custom Widgets). You can keep a copy in the repo too. |
| `story-scripts.js` | Story scripts: set-up, and using the selected tile to filter other widgets |
| `local-test.html` | Open locally to try the widget with sample data |

The widget uses no external libraries, so it doesn't need ECharts or jQuery. Nothing loads from a CDN, and SAC's content security policy can't block anything.

## Host on GitHub

1. Put `SigmaKpiPrimary.js` in the root of the `dpaonam.github.io` repository and push it.
2. Open `https://dpaonam.github.io/SigmaKpiPrimary.js` in a browser and check the code appears.
3. The manifest carries the SHA-256 `integrity` of this exact file. After **any** change to the JS:
   - regenerate the hash: `openssl dgst -sha256 -binary SigmaKpiPrimary.js | openssl base64`, prefixed with `sha256-`
   - update `integrity` and `version` in the JSON, then upload the JSON to SAC again
   - while you are still developing, you can set `"ignoreIntegrity": true` (as in the ECharts sample) and switch it back before go-live

## Data bindings (model: SAC_Load_KPI_long)

| Binding | Dimensions | Measures | Notes |
|---|---|---|---|
| `kpiBinding` | KPI_Primary, optionally Impact | Score (Average), optionally Contribution | The tile values, aggregated by SAC for the current filters |
| `trendBinding` | KPI_Primary, then Date (day or week) | Score (Average) | Add a dynamic time filter for the last 90 days |

- **Contribution or Impact not bound:** the widget calculates them with the prototype's rules. The weights come from the `weights` property and the target from `target` (80). Impact is High at 3 points or more, Medium from 1.
- **Only `trendBinding` bound:** the tile score is the latest point of the trend.
- **Overall Performance** is hidden by default (the `excludeKpis` property).
- **Tile names** must match the KPI_Primary members (e.g. "Cost Effectiveness"). The widget shows the short labels from the prototype (Wrench-time, Cost eff.).
