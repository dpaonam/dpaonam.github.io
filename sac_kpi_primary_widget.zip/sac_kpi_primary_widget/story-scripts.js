// =====================================================================================
// Story scripts for the Sigma Primary KPI Tiles widget (SAC Optimized Story, scripting on)
// Widget and object names are examples; rename them to match your story.
//   SigmaKpiPrimary_1  the custom widget
//   HeatMap_1          heat map / scorecard on the long-format model (KPI_Primary on an axis)
//   GeoMap_1           map coloured by Score
// =====================================================================================

// -------------------------------------------------------------------------------------
// Story / Page > onInitialization
// -------------------------------------------------------------------------------------
SigmaKpiPrimary_1.setTarget(80);
SigmaKpiPrimary_1.setTrendDays(90);
SigmaKpiPrimary_1.setWeights("Safety:22,Productivity:16,Cost Effectiveness:16,Schedule Adherence:13,Quality:12,Customer Satisfaction:11,Human Performance:10");


// -------------------------------------------------------------------------------------
// SigmaKpiPrimary_1 > onSelect
// Clicking a tile makes that KPI the measure for the rest of the page, as in the
// prototype. Clicking the same tile again clears the selection.
// KPI_Primary member IDs must match the tile names (they do in SAC_Load_KPI_long).
// -------------------------------------------------------------------------------------
var kpi = SigmaKpiPrimary_1.getSelectedKpi();
var targets = [HeatMap_1.getDataSource(), GeoMap_1.getLayer(0).getDataSource()];

for (var i = 0; i < targets.length; i++) {
	if (kpi === "") {
		targets[i].removeDimensionFilter("KPI_Primary");
	} else {
		targets[i].setDimensionFilter("KPI_Primary", kpi);
	}
}
// If GeoMap_1.getLayer(...) is not available in your release, remove the map from the
// list and use linked analysis for the map instead.
